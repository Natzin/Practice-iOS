Table Editing
=============

This is a very simple sample that demonstrates how to implement swipe-to-delete and 'edit mode' in UITableView with MonoTouch.

Authors
-------

Bryan Costanich
